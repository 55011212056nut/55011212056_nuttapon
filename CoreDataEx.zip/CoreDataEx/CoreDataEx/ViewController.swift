//
//  ViewController.swift
//  CoreDataEx
//
//  Created by iStudents on 3/20/15.
//  Copyright (c) 2015 iStudents. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController,UITableViewDataSource {
    
    
    
    //var items = [String]()
    var items = [NSManagedObject]()
    
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("Cell") as UITableViewCell
        
        let item = items[indexPath.row]
        cell.textLabel!.text = item.valueForKey("name") as String?
        
        
        return cell
    }

    
    
    
    
    
    
    @IBAction func additem(sender: AnyObject) {
        
        
        var alert = UIAlertController(title: "New item", message: "Add a new item", preferredStyle: .Alert)
        
        
        let saveAction = UIAlertAction(title: "Save", style: .Default) { (action: UIAlertAction!) -> Void in
            
            let textField = alert.textFields![0] as UITextField
            self.saveName(textField.text)
            self.tableView.reloadData()
        }
        
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .Default) { (action: UIAlertAction!) -> Void in
        
        
        
        }
        alert.addTextFieldWithConfigurationHandler { (textField: UITextField!) -> Void in
            
            
        }
        
        
        
        
        
        alert.addAction(saveAction)
        alert.addAction(cancelAction)
        
        presentViewController(alert, animated: true, completion: nil)
    }
    
    
    
    func saveName (name: String){
    
    let appDelegate = UIApplication.sharedApplication().delegate as AppDelegate
        
    let managedContext = appDelegate.managedObjectContext!
        
        
    let entity = NSEntityDescription.entityForName("Item", inManagedObjectContext: managedContext)
    
       let item = NSManagedObject(entity: entity!, insertIntoManagedObjectContext: managedContext)
        
        
        item.setValue(name,forKey: "name")
        
        var error: NSError?
        if !managedContext.save(&error) {
            
            println("Could not save \(error), \(error?.userInfo)")
        
        }
        
        items.append(item)
        
    
    }
    
    
    
    
    @IBOutlet weak var tableView: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "\"Shopping List\""
        tableView.registerClass(UITableViewCell.self, forCellReuseIdentifier: "Cell")
        // Do any additional setup after loading the view, typically from a nib.
        
     
        
        
    }
    
    
    
    

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    
    override func viewWillAppear (animated: Bool){
        
        super.viewWillAppear(animated)
        
        
        let appDelegate = UIApplication.sharedApplication().delegate as AppDelegate
        
        let managedContext = appDelegate.managedObjectContext!
        let fetchRequest = NSFetchRequest(entityName: "Item")
        
        var error: NSError?
        let fetchedResults = managedContext.executeFetchRequest(fetchRequest, error: &error) as [NSManagedObject]?
        
        
        if let result = fetchedResults{
            
            items = result
            
        } else {
            
            println("Could not detch \(error),\(error!.userInfo)")
        }
        
        
        
        
        
        
        
        
        
        
        
    }
    

    
    
}